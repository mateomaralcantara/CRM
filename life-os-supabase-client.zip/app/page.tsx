import { supabase } from "@/lib/supabase";

function monthRange(date = new Date()) {
  const start = new Date(date.getFullYear(), date.getMonth(), 1);
  const end = new Date(date.getFullYear(), date.getMonth() + 1, 1);
  return { start, end };
}

export default async function Page() {
  const now = new Date();
  const { start, end } = monthRange(now);

  const [{ data: tasksTodayData }, { data: objectives }, { data: txs }, { data: events }] = await Promise.all([
    supabase.from("tasks").select("id, due, status"),
    supabase.from("objectives").select("*").order("created_at", { ascending: false }).limit(3),
    supabase.from("transactions").select("*").gte("date", start.toISOString()).lt("date", end.toISOString()),
    supabase.from("events").select("*").gte("start", now.toISOString()).order("start", { ascending: true }).limit(5)
  ]);

  const tasksToday = (tasksTodayData ?? []).filter(t => t.status === "Hoy" || (t.due && new Date(t.due).toDateString() === now.toDateString())).length;
  const txList = txs ?? [];
  const monthIncome = txList.filter(t => t.kind === "Ingreso").reduce((a,t)=> a + Number(t.amount), 0);
  const monthExpense = txList.filter(t => t.kind !== "Ingreso").reduce((a,t)=> a + Number(t.amount), 0);
  const net = monthIncome - monthExpense;

  return (
    <div className="grid">
      <section className="kpis">
        <div className="kpi"><div>Tareas hoy</div><div style={{fontSize:28, fontWeight:800}}>{tasksToday}</div></div>
        <div className="kpi"><div>Ingresos (mes)</div><div style={{fontSize:28, fontWeight:800}}>{monthIncome.toLocaleString('es-DO',{style:'currency',currency:'DOP'})}</div></div>
        <div className="kpi"><div>Gastos (mes)</div><div style={{fontSize:28, fontWeight:800}}>{monthExpense.toLocaleString('es-DO',{style:'currency',currency:'DOP'})}</div></div>
        <div className="kpi"><div>Balance (mes)</div><div style={{fontSize:28, fontWeight:800}}>{net.toLocaleString('es-DO',{style:'currency',currency:'DOP'})}</div></div>
      </section>

      <section className="grid" style={{gridTemplateColumns:'1fr 1fr'}}>
        <div className="card">
          <h3 style={{marginTop:0}}>Metas destacadas</h3>
          {!objectives?.length && <p>No hay metas aún.</p>}
          {objectives?.map((o:any) => (
            <div key={o.id} style={{marginBottom:12}}>
              <div className="flex"><strong>{o.title}</strong><span className="badge">{o.area}</span><span className="badge">{o.status}</span></div>
              <div className="progress"><span style={{width: Math.min(100, Math.max(0, o.progress)) + '%'}}></span></div>
              <small>Progreso: {o.progress}% — {new Date(o.start_date).toLocaleDateString('es-DO')} → {new Date(o.end_date).toLocaleDateString('es-DO')}</small>
            </div>
          ))}
        </div>

        <div className="card">
          <h3 style={{marginTop:0}}>Próximos eventos</h3>
          {!events?.length && <p>No hay eventos próximos.</p>}
          <ul>
            {events?.map((e:any) => (
              <li key={e.id} className="flex" style={{justifyContent:'space-between'}}>
                <span><strong>{e.title}</strong> <small>{e.location ?? ''}</small></span>
                <small>{new Date(e.start).toLocaleString('es-DO')}</small>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
