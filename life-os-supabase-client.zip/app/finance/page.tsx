import { supabase } from "@/lib/supabase";

function monthRange(date = new Date()) {
  const start = new Date(date.getFullYear(), date.getMonth(), 1);
  const end = new Date(date.getFullYear(), date.getMonth() + 1, 1);
  return { start, end };
}

async function createAccount(form: FormData) {
  "use server";
  const name = String(form.get("name") || "");
  const type = String(form.get("type") || "Banco");
  const starting_bal = Number(form.get("starting_bal") || 0);
  if (!name) return;
  await supabase.from("accounts").insert({ name, type, starting_bal });
}

async function createTx(form: FormData) {
  "use server";
  const account_id = String(form.get("account_id") || "");
  const kind = String(form.get("kind") || "Egreso");
  const category = String(form.get("category") || "Otro");
  const amount = Number(form.get("amount") || 0);
  const date = String(form.get("date") || "") || new Date().toISOString();
  if (!account_id || !amount) return;
  await supabase.from("transactions").insert({ account_id, kind, category, amount, date, tags: [] });
}

export default async function FinancePage() {
  const now = new Date();
  const { start, end } = monthRange(now);

  const [{ data: accounts }, { data: txs }] = await Promise.all([
    supabase.from("accounts").select("*").order("created_at", { ascending: true }),
    supabase.from("transactions").select("*, accounts(name)").order("date", { ascending: false })
  ]);

  const monthTxs = (txs??[]).filter((t:any) => new Date(t.date) >= start && new Date(t.date) < end);
  const incomes = monthTxs.filter((t:any) => t.kind === "Ingreso").reduce((acc:number, t:any) => acc + Number(t.amount), 0);
  const expenses = monthTxs.filter((t:any) => t.kind !== "Ingreso").reduce((acc:number, t:any) => acc + Number(t.amount), 0);
  const net = incomes - expenses;

  const starting = (accounts??[]).reduce((acc:number, a:any) => acc + Number(a.starting_bal), 0);
  const running = starting + (txs??[]).reduce((acc:number, t:any) => acc + (t.kind === "Ingreso" ? Number(t.amount) : -Number(t.amount)), 0);

  return (
    <div className="grid" style={{gridTemplateColumns:'1fr 1fr'}}>
      <section className="card">
        <h2 style={{marginTop:0}}>Cuentas</h2>
        <form action={createAccount} className="flex" style={{alignItems:'end'}}>
          <div style={{flex:1}}><label>Nombre</label><input name="name" placeholder="Cuenta Banco" required /></div>
          <div><label>Tipo</label><input name="type" defaultValue="Banco" /></div>
          <div><label>Saldo inicial</label><input name="starting_bal" type="number" defaultValue={0} /></div>
          <div><button>Agregar</button></div>
        </form>
        <table style={{marginTop:16}}>
          <thead><tr><th>Nombre</th><th>Tipo</th><th className="right">Saldo inicial</th></tr></thead>
          <tbody>
            {(accounts??[]).map((a:any) => (
              <tr key={a.id}>
                <td>{a.name}</td>
                <td>{a.type}</td>
                <td className="right">{Number(a.starting_bal).toLocaleString('es-DO', { style:'currency', currency:'DOP' })}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="card">
        <h2 style={{marginTop:0}}>Transacciones</h2>
        <form action={createTx} style={{display:'grid', gap:12, gridTemplateColumns:'1fr 1fr 1fr 1fr 1fr'}}>
          <div><label>Cuenta</label>
            <select name="account_id" required>
              <option value="">-- selecciona --</option>
              {(accounts??[]).map((a:any) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </div>
          <div><label>Tipo</label><select name="kind"><option>Ingreso</option><option>Egreso</option><option>Transferencia</option></select></div>
          <div><label>Categoría</label><input name="category" defaultValue="Otro" /></div>
          <div><label>Monto</label><input name="amount" type="number" step="0.01" required /></div>
          <div><label>Fecha</label><input name="date" type="date" /></div>
          <div style={{gridColumn:'1/-1', justifySelf:'end'}}><button>Registrar</button></div>
        </form>

        <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginTop:12}}>
          <div className="kpi"><div>Ingresos (mes)</div><div style={{fontSize:24, fontWeight:800}}>{incomes.toLocaleString('es-DO',{style:'currency',currency:'DOP'})}</div></div>
          <div className="kpi"><div>Gastos (mes)</div><div style={{fontSize:24, fontWeight:800}}>{expenses.toLocaleString('es-DO',{style:'currency',currency:'DOP'})}</div></div>
          <div className="kpi"><div>Balance (mes)</div><div style={{fontSize:24, fontWeight:800}}>{net.toLocaleString('es-DO',{style:'currency',currency:'DOP'})}</div></div>
        </div>

        <table style={{marginTop:16}}>
          <thead><tr><th>Fecha</th><th>Cuenta</th><th>Tipo</th><th>Categoría</th><th className="right">Monto</th></tr></thead>
          <tbody>
            {(txs??[]).map((t:any) => (
              <tr key={t.id}>
                <td>{new Date(t.date).toLocaleDateString('es-DO')}</td>
                <td>{t.accounts?.name ?? '-'}</td>
                <td>{t.kind}</td>
                <td>{t.category}</td>
                <td className="right" style={{color: t.kind === "Ingreso" ? "#86efac" : "#fca5a5"}}>
                  {Number(t.amount).toLocaleString('es-DO', { style:'currency', currency:'DOP' })}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div style={{marginTop:12}}><small>Balance estimado total: <strong>{running.toLocaleString('es-DO',{style:'currency',currency:'DOP'})}</strong></small></div>
      </section>
    </div>
  );
}
