import "./globals.css";
import Link from "next/link";
import type { ReactNode } from "react";

export const metadata = { title: "Life OS — Supabase", description: "CRM personal con Supabase (sin Prisma)" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <body>
        <header>
          <h1 style={{marginBottom:8}}>⚡ Life OS — Supabase</h1>
          <nav>
            <Link href="/">Dashboard</Link>
            <Link href="/tasks">Tareas</Link>
            <Link href="/projects">Proyectos</Link>
            <Link href="/objectives">Metas</Link>
            <Link href="/finance">Finanzas</Link>
            <Link href="/agenda">Agenda</Link>
            <Link href="/contacts">Contactos</Link>
          </nav>
        </header>
        <main>{children}</main>
        <footer><small>Next.js + @supabase/supabase-js. Sin Prisma, sin DATABASE_URL.</small></footer>
      </body>
    </html>
  );
}
